<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Oppgave 1: myndig eller ikke</h1>


<?php


$navn = "Adrian";
$alder = 20;


//Sjekker at alder er 18 eller over og at navn = Arian
if ($alder >= 18 && $navn = "Adrian") {

    //Printer hvis betingelsene er godkjent
    printf("$navn er $alder år gammel og er dermed myndig");

    //Printer hvis betingelsene ikke er godkjent
} else printf("$navn er $alder år gammel og er ikke dermed myndig");





?>


</body>
</html>